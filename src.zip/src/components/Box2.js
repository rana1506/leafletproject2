import React from 'react'
import ShipComponent from './ShipComponent' 
import DisplayShip from './DisplayShip'

function Box2() {
  return (
    <div >
      <DisplayShip/>    
    </div>
  )
}

export default Box2
