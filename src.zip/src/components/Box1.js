import React from 'react'

function Box1() {
  return (
    <div>
      
    </div>
  )
}

export default Box1
