//import React from 'react'
//import Box1 from './Box1';
//import Box2 from './Box2';
import LeafletComponent from './LeafletComponent'
import ShipComponent from './ShipComponent'
//import "../styles.css";
function MainComponent() {
  return (
    <div className='maincomponent'>        
            <LeafletComponent/>  
    </div>
  )
}

export default MainComponent
